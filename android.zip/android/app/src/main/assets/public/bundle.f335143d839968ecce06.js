(()=>{"use strict";Object.freeze({CLAMP:1,LOOP:2}),Object.freeze({PLAY:1,STOP:2,PAUSE:3})})();
//# sourceMappingURL=bundle.f335143d839968ecce06.js.map