/*! For license information please see chunk-CXKSXL5C.js.LICENSE.txt */
var e={NONE:0,GEODESIC:1,RHUMB:2},t=Object.freeze(e);export{t as a};