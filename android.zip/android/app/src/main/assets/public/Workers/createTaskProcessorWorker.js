/*! For license information please see createTaskProcessorWorker.js.LICENSE.txt */
import{a}from"./chunk-2SKW2VRQ.js";import"./chunk-ZLUSVROX.js";export{a as default};