/*! For license information please see chunk-2DNLGXTL.js.LICENSE.txt */
var e={NONE:0,TOP:1,ALL:2},t=Object.freeze(e);export{t as a};